package dev.lifesteal;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class LifestealPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final int DEFAULT_HEARTS = 10;
    private static final int MAX_HEARTS = 20;
    private static final long BAN_MILLIS = 36L * 60 * 60 * 1000; // 36 real-life hours

    private final Map<UUID, Integer> hearts = new ConcurrentHashMap<>();
    private final Map<UUID, Long> bans = new ConcurrentHashMap<>();
    private File dataFile;
    private NamespacedKey heartItemKey;

    @Override
    public void onEnable() {
        heartItemKey = new NamespacedKey(this, "heart_item");
        dataFile = new File(getDataFolder(), "data.yml");
        loadData();

        Bukkit.getPluginManager().registerEvents(this, this);
        for (String cmd : new String[]{"withdraw", "hearts", "lifesteal"}) {
            var c = getCommand(cmd);
            if (c != null) {
                c.setExecutor(this);
                c.setTabCompleter(this);
            }
        }
        for (Player p : Bukkit.getOnlinePlayers()) applyHearts(p);
    }

    @Override
    public void onDisable() {
        saveData();
    }

    // ------------------------------------------------------------------ data

    private void loadData() {
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection h = yml.getConfigurationSection("hearts");
        if (h != null) for (String k : h.getKeys(false)) {
            try { hearts.put(UUID.fromString(k), h.getInt(k)); } catch (IllegalArgumentException ignored) {}
        }
        ConfigurationSection b = yml.getConfigurationSection("bans");
        if (b != null) for (String k : b.getKeys(false)) {
            try { bans.put(UUID.fromString(k), b.getLong(k)); } catch (IllegalArgumentException ignored) {}
        }
    }

    private synchronized void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        hearts.forEach((u, v) -> yml.set("hearts." + u, v));
        bans.forEach((u, v) -> yml.set("bans." + u, v));
        try {
            getDataFolder().mkdirs();
            yml.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Could not save data.yml: " + e.getMessage());
        }
    }

    private int getHearts(UUID id) {
        return hearts.getOrDefault(id, DEFAULT_HEARTS);
    }

    private void applyHearts(Player p) {
        AttributeInstance attr = p.getAttribute(Attribute.MAX_HEALTH);
        if (attr == null) return;
        double max = Math.max(2.0, getHearts(p.getUniqueId()) * 2.0);
        attr.setBaseValue(max);
        if (p.getHealth() > max) p.setHealth(max);
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        UUID id = e.getUniqueId();
        Long until = bans.get(id);
        if (until == null) return;

        long now = System.currentTimeMillis();
        if (until > now) {
            long mins = (until - now) / 60000 + 1;
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED,
                    Component.text("You lost all your hearts!\n", NamedTextColor.RED)
                            .append(Component.text("You are banned for another " + (mins / 60) + "h " + (mins % 60) + "m.", NamedTextColor.GRAY)));
        } else {
            // Ban over -> revived with default hearts
            bans.remove(id);
            hearts.put(id, DEFAULT_HEARTS);
            Bukkit.getScheduler().runTask(this, this::saveData);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        applyHearts(e.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            applyHearts(p);
            AttributeInstance attr = p.getAttribute(Attribute.MAX_HEALTH);
            if (attr != null) p.setHealth(attr.getValue());
        }, 1L);
    }

    /** Totem pop = +1 heart (max 20). Only fires un-cancelled if a totem really got used. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTotem(EntityResurrectEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        int h = getHearts(p.getUniqueId());
        if (h >= MAX_HEARTS) {
            p.sendMessage(Component.text("You are already at the max of " + MAX_HEARTS + " hearts.", NamedTextColor.YELLOW));
            return;
        }
        hearts.put(p.getUniqueId(), h + 1);
        applyHearts(p);
        saveData();
        p.sendMessage(Component.text("Totem popped: +1 heart! (" + (h + 1) + "/" + MAX_HEARTS + ")", NamedTextColor.GREEN));
    }

    /** Only a kill by another player moves hearts. Other deaths cost nothing. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;

        int vHearts = Math.max(0, getHearts(victim.getUniqueId()) - 1);
        hearts.put(victim.getUniqueId(), vHearts);

        int kHearts = getHearts(killer.getUniqueId());
        if (kHearts < MAX_HEARTS) {
            hearts.put(killer.getUniqueId(), kHearts + 1);
            applyHearts(killer);
            killer.sendMessage(Component.text("You stole a heart from " + victim.getName() + "! ("
                    + (kHearts + 1) + "/" + MAX_HEARTS + ")", NamedTextColor.GREEN));
        } else {
            killer.sendMessage(Component.text("You are already at the max of " + MAX_HEARTS + " hearts.", NamedTextColor.YELLOW));
        }

        if (vHearts <= 0) {
            bans.put(victim.getUniqueId(), System.currentTimeMillis() + BAN_MILLIS);
            saveData();
            Bukkit.getScheduler().runTask(this, () -> victim.kick(
                    Component.text("You lost all your hearts!\n", NamedTextColor.RED)
                            .append(Component.text("You are banned for 36 hours.", NamedTextColor.GRAY))));
            Bukkit.broadcast(Component.text(victim.getName() + " lost all their hearts and is eliminated for 36 hours!", NamedTextColor.DARK_RED));
        } else {
            saveData();
            victim.sendMessage(Component.text("You lost a heart! (" + vHearts + "/" + MAX_HEARTS + ")", NamedTextColor.RED));
        }
    }

    /** Right click a Heart item to redeem it. */
    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item == null || !isHeartItem(item)) return;

        e.setCancelled(true);
        Player p = e.getPlayer();
        int h = getHearts(p.getUniqueId());
        if (h >= MAX_HEARTS) {
            p.sendMessage(Component.text("You are already at the max of " + MAX_HEARTS + " hearts.", NamedTextColor.YELLOW));
            return;
        }
        item.setAmount(item.getAmount() - 1);
        hearts.put(p.getUniqueId(), h + 1);
        applyHearts(p);
        saveData();
        p.sendMessage(Component.text("+1 heart! (" + (h + 1) + "/" + MAX_HEARTS + ")", NamedTextColor.GREEN));
    }

    private boolean isHeartItem(ItemStack item) {
        if (!item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(heartItemKey, PersistentDataType.BYTE);
    }

    private ItemStack createHeartItem(int amount) {
        ItemStack item = new ItemStack(Material.NETHER_STAR, amount);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Heart", NamedTextColor.RED, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Right click to gain 1 heart", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(heartItemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    // -------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "withdraw" -> withdraw(sender, args);
            case "hearts" -> showHearts(sender, args);
            case "lifesteal" -> admin(sender, args);
        }
        return true;
    }

    private void withdraw(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return;
        }
        int amount = 1;
        if (args.length > 0) {
            try { amount = Integer.parseInt(args[0]); } catch (NumberFormatException ex) {
                p.sendMessage(Component.text("Usage: /withdraw [amount]", NamedTextColor.RED));
                return;
            }
        }
        int h = getHearts(p.getUniqueId());
        if (amount < 1) {
            p.sendMessage(Component.text("Amount must be at least 1.", NamedTextColor.RED));
            return;
        }
        if (h - amount < 1) {
            p.sendMessage(Component.text("You must keep at least 1 heart. You have " + h + ".", NamedTextColor.RED));
            return;
        }
        hearts.put(p.getUniqueId(), h - amount);
        applyHearts(p);
        saveData();

        var leftover = p.getInventory().addItem(createHeartItem(amount));
        leftover.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
        p.sendMessage(Component.text("Withdrew " + amount + " heart(s). You now have " + (h - amount) + ".", NamedTextColor.GREEN));
    }

    private void showHearts(CommandSender sender, String[] args) {
        if (args.length > 0) {
            OfflinePlayer t = Bukkit.getOfflinePlayerIfCached(args[0]);
            if (t == null) {
                sender.sendMessage(Component.text("Unknown player.", NamedTextColor.RED));
                return;
            }
            sender.sendMessage(Component.text(args[0] + " has " + getHearts(t.getUniqueId()) + " hearts.", NamedTextColor.YELLOW));
        } else if (sender instanceof Player p) {
            p.sendMessage(Component.text("You have " + getHearts(p.getUniqueId()) + "/" + MAX_HEARTS + " hearts.", NamedTextColor.YELLOW));
        }
    }

    private void admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lifesteal.admin")) {
            sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(Component.text("Usage: /lifesteal <revive|sethearts> <player> [amount]", NamedTextColor.RED));
            return;
        }
        OfflinePlayer t = Bukkit.getOfflinePlayerIfCached(args[1]);
        if (t == null) {
            sender.sendMessage(Component.text("Unknown player (must have joined before).", NamedTextColor.RED));
            return;
        }
        UUID id = t.getUniqueId();
        switch (args[0].toLowerCase()) {
            case "revive" -> {
                bans.remove(id);
                hearts.put(id, DEFAULT_HEARTS);
                saveData();
                if (t.getPlayer() != null) applyHearts(t.getPlayer());
                sender.sendMessage(Component.text("Revived " + args[1] + " with " + DEFAULT_HEARTS + " hearts.", NamedTextColor.GREEN));
            }
            case "sethearts" -> {
                if (args.length < 3) {
                    sender.sendMessage(Component.text("Usage: /lifesteal sethearts <player> <1-20>", NamedTextColor.RED));
                    return;
                }
                try {
                    int n = Math.max(1, Math.min(MAX_HEARTS, Integer.parseInt(args[2])));
                    hearts.put(id, n);
                    saveData();
                    if (t.getPlayer() != null) applyHearts(t.getPlayer());
                    sender.sendMessage(Component.text("Set " + args[1] + " to " + n + " hearts.", NamedTextColor.GREEN));
                } catch (NumberFormatException ex) {
                    sender.sendMessage(Component.text("Invalid number.", NamedTextColor.RED));
                }
            }
            default -> sender.sendMessage(Component.text("Usage: /lifesteal <revive|sethearts> <player> [amount]", NamedTextColor.RED));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (cmd.getName().equalsIgnoreCase("lifesteal") && sender.hasPermission("lifesteal.admin")) {
            if (args.length == 1) {
                out.add("revive");
                out.add("sethearts");
            } else if (args.length == 2) {
                Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
            }
        } else if (cmd.getName().equalsIgnoreCase("hearts") && args.length == 1) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        }
        return out;
    }
}
