Build: install JDK 25 + Gradle, run `gradle build`.
Jar ends up in build/libs/. Upload it to the server's /plugins folder and restart.
If the 26.3 API isn't found, change 26.3.build.+ in build.gradle.kts to the newest Paper version.
