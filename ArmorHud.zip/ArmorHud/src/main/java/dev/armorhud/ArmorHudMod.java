package dev.armorhud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

public class ArmorHudMod implements ClientModInitializer {

    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static final int ALERT_BELOW_PERCENT = 10;

    @Override
    public void onInitializeClient() {
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.HOTBAR,
                Identifier.of("armorhud", "armor_hud"),
                ArmorHudMod::render);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;

        int x = 6;
        int startY = ctx.getScaledWindowHeight() / 2 - 48;

        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack stack = client.player.getEquippedStack(SLOTS[i]);
            if (stack.isEmpty() || !stack.isDamageable()) continue;

            int max = stack.getMaxDamage();
            int remaining = Math.max(0, max - stack.getDamage());
            int percent = (int) Math.ceil(remaining * 100.0 / max);
            int y = startY + i * 24;

            // item icon
            ctx.drawItem(stack, x, y);

            // vanilla-style durability bar
            int step = Math.round(13f * remaining / max);
            int color = barColor((float) remaining / max);
            ctx.fill(x + 2, y + 13, x + 15, y + 15, 0xFF000000);
            ctx.fill(x + 2, y + 13, x + 2 + step, y + 14, color);

            // percentage text
            ctx.drawText(client.textRenderer, percent + "%", x + 20, y + 4, color, true);

            // small red alert triangle above the piece
            if (percent < ALERT_BELOW_PERCENT) {
                int red = 0xFFFF2020;
                ctx.fill(x + 7, y - 5, x + 8, y - 4, red);
                ctx.fill(x + 6, y - 4, x + 9, y - 3, red);
                ctx.fill(x + 5, y - 3, x + 10, y - 2, red);
                ctx.fill(x + 7, y - 4, x + 8, y - 3, 0xFFFFFFFF); // tiny white dot
            }
        }
    }

    /** Same green -> yellow -> red look as the vanilla durability bar. */
    private static int barColor(float fraction) {
        float h6 = Math.max(0f, Math.min(1f, fraction)) / 3f * 6f;
        int i = (int) h6;
        float f = h6 - i;
        float r, g;
        if (i == 0) { r = 1f; g = f; }
        else if (i == 1) { r = 1f - f; g = 1f; }
        else { r = 0f; g = 1f; }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8);
    }
}
